/****************************************************
 *
 * Author: Nick Roy
 * Date: 4/2/2017
 * Description: Header file for the determinant class
 *
 ****************************************************/
#ifndef DETERMINANT_HPP
#define DETERMINANT_HPP

int determinant(int *myMatrix, int sizeOfMatrix);

#endif
